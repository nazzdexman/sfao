"""R2-1 full-budget experiment: learned vs randomized vs isotropic M7 geometry.

Usage (from this folder):
    python run_r21.py results            # full experiment (resumes if interrupted)
    python run_r21.py smoke --smoke      # quick test, budgets / 50, 2 seeds
    python run_r21.py results --workers 6

Every arm runs the frozen SFAO configuration (sfao_final settings). Only the
M7 sampling geometry, the M7 switch point, or the M7/M8 switches change.
Protocol and analysis are fixed in PROTOCOL.md before any run.
"""
import os
for _v in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS",
           "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[_v] = "1"

import argparse
import hashlib
import json
import platform
import sys
import time
from multiprocessing import get_context
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

SEEDS = list(range(100, 130))                 # new seeds, not used in development
VALLEY_IDS = list(range(1, 11))               # 10 independent shifted+rotated valleys
VALLEY_SEEDS = [100, 101, 102]                # 3 seeds each -> 30 instance-seed blocks
THRESH = {"CEC2017 F4": [100.0, 10.0, 1.0, 0.1, 0.01, 0.001],
          "CEC2022 F2": [1.0, 0.1, 0.01, 0.001, 1e-4, 1e-6, 1e-8],
          "valley": [1.0, 0.1, 0.01, 0.001, 1e-4, 1e-6, 1e-8]}

GEOM_ARMS = [(f"{g}_{int(sw*100)}", dict(spin_start=sw, spin_geometry=g))
             for sw in (0.65, 0.80) for g in ("learned", "randomized", "isotropic")]
CONTROL_ARMS = [("no_m7", dict(use_spin=False)),
                ("no_m8", dict(use_memory=False)),
                ("neither", dict(use_spin=False, use_memory=False))]


def problems(smoke):
    k = 50 if smoke else 1
    seeds = SEEDS[:2] if smoke else SEEDS
    out = []
    for s in seeds:
        out.append(("CEC2017 F4", 30, 300000 // k, s, None))
        out.append(("CEC2022 F2", 10, 200000 // k, s, None))
    vids = VALLEY_IDS[:2] if smoke else VALLEY_IDS
    vseeds = VALLEY_SEEDS[:1] if smoke else VALLEY_SEEDS
    for i in vids:
        for s in vseeds:
            out.append(("valley", 10, 200000 // k, s, i))
    return out


def jobs(smoke):
    out = []
    for prob in problems(smoke):
        arms = GEOM_ARMS + [CONTROL_ARMS[0]]
        if prob[0] != "CEC2022 F2":           # F2 factorial already exists (120 runs)
            arms = arms + CONTROL_ARMS[1:]
        for name, kw in arms:
            out.append((*prob, name, kw))
    return out


def make_valley(instance_id, d):
    """Shifted, rotated Rosenbrock with CEC-style scaling; optimum error 0 at x = shift."""
    rng = np.random.default_rng(10_000 + instance_id)
    a = rng.standard_normal((d, d))
    q, r = np.linalg.qr(a)
    q = q * np.sign(np.diag(r))
    shift = rng.uniform(-80.0, 80.0, d)

    def f(x):
        z = 0.02048 * (q @ (np.asarray(x) - shift)) + 1.0
        return float(np.sum(100.0 * (z[1:] - z[:-1] ** 2) ** 2 + (z[:-1] - 1.0) ** 2))
    return f


def objective(kind, d, instance_id):
    if kind == "CEC2017 F4":
        from cec2017 import CEC2017
        return CEC2017(4, d)
    if kind == "CEC2022 F2":
        from cec2022 import CEC2022
        return CEC2022(2, d)
    return make_valley(instance_id, d)


def tag(job):
    kind, d, budget, seed, inst, arm, _ = job
    p = {"CEC2017 F4": "c17f4", "CEC2022 F2": "c22f2"}[kind] if inst is None else f"valley{inst:02d}"
    return f"{p}_s{seed}_{arm}"


def run(args):
    try:
        return _run(args)
    except BaseException as e:            # StopIteration would otherwise end the pool loop silently
        import traceback
        raise RuntimeError(f"{tag(args[0])} failed:\n{traceback.format_exc()}") from None


def _run(args):
    job, outdir = args
    kind, d, budget, seed, inst, arm, kw = job
    out = Path(outdir)
    t = tag(job)
    if (out / f"{t}.json").exists():
        return t, "skip"
    from sfao_geom import SFAO
    cfg = dict(use_cocoon=True, food_per_worm=100, spin_mode="adaptive")   # = sfao_final()
    cfg.update(kw)
    f = objective(kind, d, inst)
    alg = SFAO(**cfg)
    t0 = time.time()
    best_x, best_f, curve = alg.optimize(f, d, -100, 100, budget, seed=seed)
    sec = time.time() - t0
    curve = np.asarray(curve, float)
    assert len(curve) == budget, (t, len(curve))
    idx = np.flatnonzero(np.r_[True, curve[1:] < curve[:-1]])      # improvement points
    hits = {}
    for th in THRESH["valley" if kind == "valley" else kind]:
        w = np.flatnonzero(curve < th)
        hits[repr(th)] = int(w[0] + 1) if len(w) else None
    np.savez_compressed(out / f"{t}.npz", fe=(idx + 1).astype(np.int64),
                        best_so_far=curve[idx], best_x=np.asarray(best_x))
    rec = dict(problem=kind, instance=inst, D=d, budget_fe=budget, seed=seed, arm=arm,
               config=cfg, raw_final_error=float(curve[-1]), first_hit_fe=hits,
               m7_first_fe=alg.revision_m7_first_fe, m7_evals=int(alg.revision_m7_evals),
               seconds=round(sec, 2))
    tmp = out / f"{t}.json.tmp"
    tmp.write_text(json.dumps(rec, indent=1))
    tmp.replace(out / f"{t}.json")
    return t, f"{sec:.0f}s err={curve[-1]:.4g}"


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("outdir")
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--workers", type=int, default=max(1, (os.cpu_count() or 2) - 1))
    a = ap.parse_args()
    out = Path(a.outdir)
    out.mkdir(parents=True, exist_ok=True)
    files = ["run_r21.py", "sfao_geom.py", "sfao.py", "cec2017.py", "cec2022.py",
             "PROTOCOL.md", "analyze_r21.py"]
    man = dict(smoke=a.smoke, python=sys.version, platform=platform.platform(),
               machine=platform.machine(), numpy=np.__version__,
               started=time.strftime("%Y-%m-%d %H:%M:%S"),
               sha256={f: sha(HERE / f) for f in files})
    mp = out / "manifest.json"
    if mp.exists():
        old = json.loads(mp.read_text())
        if old["sha256"] != man["sha256"] or old["smoke"] != man["smoke"]:
            sys.exit("manifest mismatch: code or mode changed since these results were started; "
                     "use a new output folder")
    else:
        mp.write_text(json.dumps(man, indent=1))
    # fail fast: every evaluator must load in the main process before workers start
    for kind, d, inst in (("CEC2017 F4", 30, None), ("CEC2022 F2", 10, None), ("valley", 10, 1)):
        objective(kind, d, inst)(np.zeros(d))
    js = jobs(a.smoke)
    todo = [j for j in js if not (out / f"{tag(j)}.json").exists()]
    print(f"{len(js)} runs in total, {len(todo)} to do, {a.workers} workers", flush=True)
    t0 = time.time()
    with get_context("spawn").Pool(a.workers) as pool:
        for n, (t, msg) in enumerate(pool.imap_unordered(run, [(j, str(out)) for j in todo]), 1):
            el = time.time() - t0
            eta = el / n * (len(todo) - n)
            print(f"[{n}/{len(todo)}] {t}: {msg}   elapsed {el/60:.0f} min, ETA {eta/60:.0f} min",
                  flush=True)
    done = sum((out / f"{tag(j)}.json").exists() for j in js)
    print(f"finished: {done}/{len(js)} runs present in {out}")
    if done < len(js):
        sys.exit("some runs are missing: run the same command again to resume")


if __name__ == "__main__":
    main()
