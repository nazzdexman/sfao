# R2-1 protocol: learned versus randomized versus isotropic late-stage geometry

Fixed on 22 November 2026, before any full-budget run. The SHA-256 of this file is stored in each results `manifest.json`. Analysis follows `analyze_r21.py` without change. Any additional analysis is reported as post hoc.

## Question

Reviewer 2, comment 1 asks whether the learned search directions help on curved valleys beyond the development case. The test must separate the geometry of the late-stage search from the allocation of evaluations to late-stage refinement.

## Algorithm and arms

All arms use the frozen SFAO configuration of the paper (`sfao_final`: `use_cocoon=True`, `food_per_worm=100`, `spin_mode="adaptive"`, all other operators at their defaults). `sfao_geom.py` is `sfao.py` with one change, shown in `sfao_geom.patch`. Each M7 sample draws `z` from the main random stream and the arm sets the sampling geometry:

| Arm | M7 step | Other operators |
|---|---|---|
| learned | B (d ⊙ z) / √D, the learned basis and spectrum (paper, Eq. 15) | unchanged |
| randomized | Q (d ⊙ z) / √D, a fresh Haar-random orthogonal basis Q at each M7 block and the same learned spectrum d | unchanged |
| isotropic | z / √D | unchanged |

The three arms share the step-size rule, the number of M7 samples per iteration, the incumbent, the main random stream and therefore the whole trajectory before the first M7 sample. `check_install.py` verifies that the learned arm at the 80% switch reproduces the original SFAO exactly and that all arms coincide before M7.

Each arm runs at two M7 switch points: 65% and 80% of the budget (paper default: 80%). The arms are named `learned_65`, …, `isotropic_80`.

There are three controls:
- `no_m7`: M7 off. The ordinary loop receives the late-stage evaluations.
- `no_m8` and `neither`: directional memory off, and both off. With `learned_80` and `no_m7` these form the M7 × M8 factorial. The factorial runs on CEC2017 F4 and the valleys only, because the CEC2022 F2 factorial already has 120 runs.

## Problems, budgets and seeds

| Family | D | Budget (FE) | Blocks |
|---|---|---|---|
| CEC2017 F4 (shifted rotated Rosenbrock; reference C code) | 30 | 300,000 | seeds 100–129 |
| CEC2022 F2 (shifted rotated Rosenbrock; reference code) | 10 | 200,000 | seeds 100–129 |
| Independent valleys | 10 | 200,000 | 10 instances × seeds 100–102 |

Each valley instance `i` uses `numpy.random.default_rng(10000 + i)` to draw a Haar-random rotation Q and a shift o ~ U(−80, 80)^D. The objective is the Rosenbrock function of z = 0.02048 Q (x − o) + 1. Its minimum error is 0 at x = o. Bounds are [−100, 100]^D, and bound handling is clipping, as in the paper.

Seeds 100–129 were not used in development or in any earlier experiment.

There are 750 runs in total: 270 on F4, 210 on F2 and 270 on the valleys.

## Outcomes

- **Primary outcome:** raw final error at the budget, with no zeroing.
- **Secondary outcomes:**
  - success at the family's primary target: error < 1 on F4, and error < 10⁻³ on F2 and the valleys;
  - first FE at which the target is reached, and ERT, defined as the total FE spent over all runs divided by the number of successes;
  - threshold sensitivity, using the targets listed in `run_r21.py`;
  - the number of evaluations spent in M7.

## Primary analysis

There are 12 confirmatory comparisons: 3 families × 2 switch points × (learned vs isotropic, learned vs randomized). Each is tested with a two-sided Wilcoxon signed-rank test on the final errors, paired by block, with `zero_method="pratt"`. The p-values are Holm-adjusted across all 12 comparisons, at α = 0.05.

For each comparison, the analysis reports:
- the paired win proportion, P(learned < other) + 0.5 P(tie);
- the median paired log10 error ratio;
- the median final errors.

**Decision rule.** A learned-geometry advantage is supported in a family only if learned has a lower median final error than both isotropic and randomized, with Holm-adjusted p < 0.05, at both switch points. A significant result in the opposite direction is reported as an advantage of the control. Any other pattern is reported as no detected geometry effect at this budget.

## Secondary and exploratory analyses

The following are reported without multiplicity adjustment and are labelled exploratory:
- each M7 arm versus `no_m7`, using a Wilcoxon signed-rank test as above, to show the effect of the late-stage allocation;
- success counts, compared with an exact McNemar test, together with Wilson intervals;
- ERT and threshold sensitivity;
- the M7 × M8 factorial (F4 and valleys): the interaction (learned_80 − no_m8 − no_m7 + neither) in success probability and in mean final error, with 95% percentile intervals from 20,000 bootstrap resamples of whole blocks (resampling seed 20261122).

## Reporting

All arms, both switches and all three families are reported, whatever the direction of the results. Results apply to this implementation and numerical environment; the manifest records the platform. Seed labels do not guarantee identical trajectories across machines.
