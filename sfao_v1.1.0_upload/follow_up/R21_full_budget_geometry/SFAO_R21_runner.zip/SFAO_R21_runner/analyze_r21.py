"""Pre-specified analysis for PROTOCOL.md.  Usage: python analyze_r21.py results"""
import json
import sys
from pathlib import Path

import numpy as np
from scipy.stats import wilcoxon, binomtest

TARGET = {"CEC2017 F4": 1.0, "CEC2022 F2": 1e-3, "valley": 1e-3}
FAMILIES = ["CEC2017 F4", "CEC2022 F2", "valley"]


def load(d):
    rows = [json.loads(p.read_text()) for p in sorted(Path(d).glob("*.json")) if p.name != "manifest.json"]
    out = {}
    for r in rows:
        fam = "valley" if r["problem"] == "valley" else r["problem"]
        block = (r["instance"], r["seed"])
        out.setdefault(fam, {}).setdefault(r["arm"], {})[block] = r
    return out


def holm(ps):
    order = np.argsort(ps)
    adj = np.empty(len(ps))
    running = 0.0
    for rank, i in enumerate(order):
        running = max(running, min(1.0, (len(ps) - rank) * ps[i]))
        adj[i] = running
    return adj


def wilson(k, n, z=1.959963984540054):
    if n == 0:
        return (np.nan, np.nan)
    p = k / n
    c = (p + z * z / (2 * n)) / (1 + z * z / n)
    h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / (1 + z * z / n)
    return (c - h, c + h)


def paired(a, b):
    blocks = sorted(set(a) & set(b), key=str)
    x = np.array([a[k]["raw_final_error"] for k in blocks])
    y = np.array([b[k]["raw_final_error"] for k in blocks])
    return blocks, x, y


def compare(a, b):
    blocks, x, y = paired(a, b)
    d = x - y
    p = 1.0 if np.all(d == 0) else float(wilcoxon(x, y, zero_method="pratt").pvalue)
    win = float(np.mean(x < y) + 0.5 * np.mean(x == y))
    ratio = float(np.median(np.log10(np.maximum(x, 1e-300) / np.maximum(y, 1e-300))))
    return dict(n=len(blocks), p=p, win_learned=win, median_log10_ratio=ratio,
                median_a=float(np.median(x)), median_b=float(np.median(y)))


def success(rs, fam):
    th = TARGET[fam]
    return {k: r["raw_final_error"] < th for k, r in rs.items()}


def first_hit(r, fam):
    th = TARGET[fam]
    key = next(k for k in r["first_hit_fe"] if float(k) == th)
    return r["first_hit_fe"][key]


def mcnemar(sa, sb):
    ks = set(sa) & set(sb)
    b = sum(sa[k] and not sb[k] for k in ks)
    c = sum(sb[k] and not sa[k] for k in ks)
    p = 1.0 if b + c == 0 else binomtest(b, b + c, 0.5).pvalue
    return dict(only_a=b, only_b=c, p_exact=float(p))


def arm_summary(rs, fam):
    e = np.array([r["raw_final_error"] for r in rs.values()])
    s = success(rs, fam)
    k, n = sum(s.values()), len(s)
    hits = [first_hit(r, fam) for r in rs.values() if s[(r["instance"], r["seed"])]]
    spent = sum(first_hit(r, fam) if s[(r["instance"], r["seed"])] else r["budget_fe"] for r in rs.values())
    sens = {}
    for th in next(iter(rs.values()))["first_hit_fe"]:
        sens[th] = int(sum(r["raw_final_error"] < float(th) for r in rs.values()))
    m7 = [r["m7_evals"] for r in rs.values()]
    return dict(n=n, mean=float(e.mean()), median=float(np.median(e)), q25=float(np.percentile(e, 25)),
                q75=float(np.percentile(e, 75)), success=k, wilson95=wilson(k, n),
                median_hit_fe=float(np.median(hits)) if hits else None,
                ert=float(spent / k) if k else None, threshold_successes=sens,
                median_m7_evals=float(np.median(m7)))


def factorial(arms, fam, reps=20000, seed=20261122):
    cells = ["learned_80", "no_m8", "no_m7", "neither"]
    if not all(c in arms for c in cells):
        return None
    blocks = sorted(set.intersection(*[set(arms[c]) for c in cells]), key=str)
    th = TARGET[fam]
    E = np.array([[arms[c][b]["raw_final_error"] for c in cells] for b in blocks])
    S = (E < th).astype(float)
    w = np.array([1, -1, -1, 1])
    rng = np.random.default_rng(seed)
    out = {}
    for name, M in (("success", S), ("mean_error", E)):
        est = float(M.mean(0) @ w)
        idx = rng.integers(0, len(blocks), (reps, len(blocks)))
        boot = M[idx].mean(1) @ w
        out[name] = dict(interaction=est, ci95=[float(np.percentile(boot, 2.5)), float(np.percentile(boot, 97.5))],
                         cell_means=dict(zip(cells, map(float, M.mean(0)))))
    out["n_blocks"] = len(blocks)
    return out


def main():
    if not list(Path(sys.argv[1]).glob("*_s*.json")):
        sys.exit(f"no run files in {sys.argv[1]}: run run_r21.py first")
    data = load(sys.argv[1])
    res = {"primary": [], "arms": {}, "vs_no_m7": [], "mcnemar": [], "factorial": {}}
    for fam in FAMILIES:
        arms = data.get(fam, {})
        res["arms"][fam] = {a: arm_summary(rs, fam) for a, rs in sorted(arms.items())}
        for sw in (65, 80):
            L = arms.get(f"learned_{sw}")
            for other in ("isotropic", "randomized"):
                O = arms.get(f"{other}_{sw}")
                if L and O:
                    c = compare(L, O)
                    res["primary"].append(dict(family=fam, switch=sw, comparison=f"learned vs {other}", **c))
                    res["mcnemar"].append(dict(family=fam, switch=sw, comparison=f"learned vs {other}",
                                               **mcnemar(success(L, fam), success(O, fam))))
            for g in ("learned", "randomized", "isotropic"):
                A, N = arms.get(f"{g}_{sw}"), arms.get("no_m7")
                if A and N:
                    res["vs_no_m7"].append(dict(family=fam, arm=f"{g}_{sw}", **compare(A, N)))
        res["factorial"][fam] = factorial(arms, fam)
    adj = holm(np.array([r["p"] for r in res["primary"]])) if res["primary"] else []
    for r, a in zip(res["primary"], adj):
        r["p_holm"] = float(a)
    verdict = {}
    for fam in FAMILIES:
        rows = [r for r in res["primary"] if r["family"] == fam]
        if len(rows) == 4:
            good = all(r["p_holm"] < .05 and r["median_a"] < r["median_b"] for r in rows)
            bad = [f'{r["comparison"]} @{r["switch"]}%' for r in rows if r["p_holm"] < .05 and r["median_a"] > r["median_b"]]
            verdict[fam] = ("learned-geometry advantage supported" if good else
                            ("control better: " + "; ".join(bad)) if bad else
                            "no detected geometry effect at this budget")
    res["verdict"] = verdict
    out = Path(sys.argv[1]) / "analysis_r21.json"
    out.write_text(json.dumps(res, indent=1))
    print(f"wrote {out}")
    for fam in FAMILIES:
        print(f"\n== {fam}: {verdict.get(fam, 'incomplete')}")
        for a, s in res["arms"][fam].items():
            print(f"  {a:14s} median {s['median']:.4g}  mean {s['mean']:.4g}  success {s['success']}/{s['n']}"
                  f"  ERT {s['ert'] if s['ert'] is None else round(s['ert'])}  M7 evals {s['median_m7_evals']:.0f}")
        for r in res["primary"]:
            if r["family"] == fam:
                print(f"  {r['comparison']:24s} @{r['switch']}%: win(learned) {r['win_learned']:.2f}"
                      f"  p {r['p']:.3g}  Holm {r['p_holm']:.3g}")


if __name__ == "__main__":
    main()
