"""Run once before the experiment (about 1-2 minutes).

1. CEC2017 evaluator agrees with the official C reference values.
2. The patched SFAO with geometry 'learned' and switch 0.80 reproduces the
   original locked SFAO (sfao.py + sfao_final settings) exactly.
3. All geometry arms share the same trajectory before the first M7 sample.
"""
import os
for _v in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
    os.environ[_v] = "1"
import sys
import time
import numpy as np

import cec2017
from cec2022 import CEC2022
from sfao import SFAO as Original
from sfao_geom import SFAO as Patched

ok = cec2017.selfcheck(verbose=True)

base = dict(use_cocoon=True, food_per_worm=100, spin_mode="adaptive")
f = CEC2022(2, 10)
budget = 20000
t0 = time.time()
_, fo, co = Original(**base).optimize(f, 10, -100, 100, budget, seed=100)
sec = time.time() - t0
_, fp, cp = Patched(**base, spin_geometry="learned").optimize(f, 10, -100, 100, budget, seed=100)
same = np.array_equal(np.asarray(co), np.asarray(cp))
print(f"learned_80 reproduces original SFAO exactly: {'PASS' if same else 'FAIL'}")
ok &= same

curves, firsts = {}, {}
for g in ("learned", "randomized", "isotropic"):
    a = Patched(**base, spin_geometry=g)
    curves[g] = np.asarray(a.optimize(f, 10, -100, 100, budget, seed=100)[2])
    firsts[g] = a.revision_m7_first_fe
m7 = firsts["learned"]
shared = all(firsts[g] == m7 for g in firsts) and all(
    np.array_equal(curves[g][:m7 - 1], curves["learned"][:m7 - 1]) for g in curves)
print(f"arms identical before first M7 sample (FE {m7}): {'PASS' if shared else 'FAIL'}")
ok &= shared

print(f"one 20,000-FE F2 run took {sec:.1f} s on this machine")
print("ALL CHECKS PASSED" if ok else "CHECK FAILED - do not run the experiment; send this output")
sys.exit(0 if ok else 1)
