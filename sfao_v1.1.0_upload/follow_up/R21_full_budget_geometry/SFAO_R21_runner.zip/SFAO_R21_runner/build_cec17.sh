#!/bin/sh
# Compile the official CEC2017 C code for the Python that will run the experiment
# (arm64 or x86_64/Rosetta). Needs Xcode command-line tools: xcode-select --install
set -e
cd "$(dirname "$0")"
ARCH=$(python3 -c "import platform; print(platform.machine())")
echo "Python architecture: $ARCH"
clang++ -O2 -std=c++11 -shared -fPIC -arch "$ARCH" -o cec2017_data/libcec17_local.so cec2017_data/cec17_lib.cpp
python3 cec2017.py && echo "CEC2017 library built and verified for $ARCH"
