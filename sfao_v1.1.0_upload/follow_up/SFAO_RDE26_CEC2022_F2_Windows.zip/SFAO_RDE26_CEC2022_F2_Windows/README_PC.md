# รัน SFAO เทียบ RDE26-SOP บน Windows PC

ชุดนี้ใช้ **WSL Ubuntu** สำหรับคอมไพล์ RDE26-SOP และรันทั้งสองอัลกอริทึมใน Linux environment เดียวกัน

## เตรียมครั้งแรก

ถ้ายังไม่มี WSL Ubuntu ให้เปิด PowerShell แบบ Administrator แล้วรัน `wsl --install -d Ubuntu` จากนั้นรีสตาร์ตหากระบบขอ เปิด Ubuntu ตั้งค่าผู้ใช้ครั้งแรก แล้วรันในหน้าต่าง Ubuntu

```bash
sudo apt update
sudo apt install -y build-essential python3 python3-venv
```

## ดับเบิลคลิกเพื่อรัน

แตก ZIP ให้ครบ แล้วดับเบิลคลิก `RUN_WINDOWS.bat` กด 2 เพื่อทดสอบสั้น หรือกด 1 เพื่อรันชุดเต็มและรันต่อจากผลที่บันทึกแล้ว

## รันจาก PowerShell

แตก ZIP เข้าโฟลเดอร์ที่มีไฟล์ `run_pc.sh` แล้วเปิด PowerShell จากโฟลเดอร์นั้น ใช้คำสั่งต่อไปนี้ทีละบรรทัด

```powershell
wsl -d Ubuntu bash ./run_pc.sh --smoke --workers 2
```

เมื่อทดสอบผ่าน ให้รันชุดจริง

```powershell
wsl -d Ubuntu bash ./run_pc.sh --workers 4
```

ชุดจริงใช้ CEC2022 F2 ขนาด 10 มิติ ขอบเขต [−100, 100] งบ 200,000 FE ต่อรอบ seed 0–29 ต่ออัลกอริทึม รวม 60 รอบ ทั้งสองตัวใช้ error จาก optimum เดียวกัน โค้ด RDE26-SOP ใช้พารามิเตอร์ต้นฉบับจาก commit 877e68555ecbed73d05b98c57a196a3a0d1d3147 เปลี่ยนฟังก์ชันประเมินให้เป็น CEC2022 F2 และเพิ่มตัวนับเพื่อตรวจขอบเขตงบกับบันทึก FE ที่เข้าเป้า ก่อนรันจะตรวจ evaluator ทั้งสองที่จุดสุ่มและจุดใกล้ optimum

ผลชุดจริงอยู่ที่ `results` และรอบทดสอบอยู่ที่ `results_smoke` ถ้าหยุดกลางคัน ใช้คำสั่งเดิมเพื่อรันต่อจาก seed ที่บันทึกครบแล้ว เมื่อรันครบ ให้ส่ง ZIP ของโฟลเดอร์ `results` ทั้งโฟลเดอร์กลับมา

```powershell
Compress-Archive -Path .\results -DestinationPath .\SFAO_RDE26_CEC2022_F2_results.zip
```

- `run_summary.csv` มีผลราย seed และ FE แรกที่ error ต่ำกว่า 0.001 ช่องว่างหมายถึงไม่เข้าเป้า
- `summary.json` สรุปค่าเฉลี่ย มัธยฐาน ส่วนเบี่ยงเบนมาตรฐานของ error ดิบ และจำนวนรอบที่เข้าเป้าแยกตามอัลกอริทึม
- `manifest.json` และ `evaluator_check.json` บันทึกสภาพแวดล้อม ข้อมูลตั้งต้น และผลตรวจ evaluator
- ไฟล์ NPZ ของ SFAO เก็บ best-so-far ทุก FE ส่วน RDE26-SOP เก็บ FE ที่ผลดีขึ้นและ FE สุดท้าย
