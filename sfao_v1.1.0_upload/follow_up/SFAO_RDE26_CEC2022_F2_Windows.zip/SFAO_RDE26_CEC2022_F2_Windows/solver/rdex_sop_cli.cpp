#include "rdex_sop.h"
#include "cec2022_f2.h"
#include <iostream>
#include <string>

int main(int argc, char** argv) {
    if (argc != 3 && argc != 4) return 2;
    try {
        load_cec2022_f2(argv[1]);
        if (argc == 3 && std::string(argv[2]) == "--check") {
            std::array<double, 10> x{};
            std::cout.precision(17);
            while (std::cin >> x[0]) {
                for (int i = 1; i < 10; ++i)
                    if (!(std::cin >> x[i])) return 2;
                std::cout << cec2022_f2(x.data()) << '\n';
            }
            return 0;
        }
        if (argc != 4) return 2;
        set_random_seed(static_cast<unsigned>(std::stoul(argv[2])));
        run_rdex_sop_s2_xover_w0_ed60_rm2p0_c02_d1_cec2017(
            10, 2, -100.0, 100.0, std::stoi(argv[3]));
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
