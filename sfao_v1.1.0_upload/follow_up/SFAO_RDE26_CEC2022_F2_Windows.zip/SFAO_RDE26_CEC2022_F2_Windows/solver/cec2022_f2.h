#pragma once
#include <array>
#include <fstream>
#include <stdexcept>
#include <string>

inline std::array<double, 10> shift_f2{};
inline std::array<double, 100> rotation_f2{};

inline void load_cec2022_f2(const std::string& data_dir) {
    std::ifstream shift(data_dir + "/shift_data_2.txt");
    std::ifstream rotation(data_dir + "/M_2_D10.txt");
    for (double& value : shift_f2)
        if (!(shift >> value)) throw std::runtime_error("Could not load F2 shift data");
    for (double& value : rotation_f2)
        if (!(rotation >> value)) throw std::runtime_error("Could not load F2 rotation data");
}

inline double cec2022_f2(const double* x) {
    std::array<double, 10> scaled{}, z{};
    for (int i = 0; i < 10; ++i) scaled[i] = (x[i] - shift_f2[i]) * (2.048 / 100.0);
    for (int i = 0; i < 10; ++i) {
        for (int j = 0; j < 10; ++j) z[i] += rotation_f2[10*i+j] * scaled[j];
        z[i] += 1.0;
    }
    double error = 0.0;
    for (int i = 0; i < 9; ++i) {
        const double a = z[i]*z[i] - z[i+1];
        const double b = z[i] - 1.0;
        error += 100.0*a*a + b*b;
    }
    return error;
}
