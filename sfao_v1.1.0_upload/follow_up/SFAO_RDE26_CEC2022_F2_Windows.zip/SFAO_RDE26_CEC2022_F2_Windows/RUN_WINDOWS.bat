@echo off
setlocal
cd /d "%~dp0" || exit /b 1
wsl.exe -d Ubuntu -- true >nul 2>&1
if errorlevel 1 goto setup
wsl.exe -d Ubuntu -- bash -c "command -v g++ >/dev/null && python3 -c 'import venv' && python3 -c 'import ensurepip'" >nul 2>&1
if errorlevel 1 goto setup
echo [1] Run full experiment - 60 runs, or resume
echo [2] Run a short test
echo [Q] Quit
choice /c 12Q /n /m "Choose an option: "
if errorlevel 3 exit /b 0
if errorlevel 2 goto smoke
wsl.exe -d Ubuntu -- bash ./run_pc.sh --workers 4
goto done

:smoke
wsl.exe -d Ubuntu -- bash ./run_pc.sh --smoke --workers 2
goto done

:setup
echo Ubuntu or its dependencies are missing. See README_PC.md for first-time setup.
pause
exit /b 1

:done
set "status=%errorlevel%"
if not "%status%"=="0" echo Run failed. Check the message above.
pause
exit /b %status%
