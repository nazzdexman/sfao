"""Run SFAO and RDE26-SOP on CEC2022 F2 with matched budgets."""
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import csv
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys

from run_f2 import BUDGET, ROOT, TARGET, ZERO, run_seed, write_json
import numpy as np
from cec2022 import CEC2022

DATA = ROOT / 'cec2022_data' / 'input_data'
SOURCE = ROOT / 'solver'
PIN = '877e68555ecbed73d05b98c57a196a3a0d1d3147'


def build(out, compiler):
    binary = out / 'rde26_f2'
    subprocess.run([
        compiler, '-O3', '-std=c++17', '-pthread', '-ffp-contract=off',
        'rdex_sop_cli.cpp', 'rdex_sop.cpp', 'cec17_func.cpp',
        'problem_bridge.cpp', '-I.', '-o', str(binary),
    ], cwd=SOURCE, check=True)
    return binary


def check_evaluator(binary):
    objective = CEC2022(2, 10)
    rng = np.random.default_rng(415)
    optimum = objective.x_opt()
    points = list(rng.uniform(-100, 100, size=(200, 10)))
    points += [optimum]
    for scale in (1e-8, 1e-5, 1e-2, 1.0):
        points += list(optimum + rng.normal(0, scale, size=(20, 10)))
    sample = ''.join(' '.join(map(str, point)) + '\n' for point in points)
    actual = np.array(subprocess.check_output(
        [str(binary), str(DATA), '--check'], input=sample, text=True
    ).splitlines(), dtype=float)
    expected = np.array([objective(point) for point in points])
    np.testing.assert_allclose(actual, expected, rtol=1e-12, atol=1e-12)
    return {'points': len(points), 'max_absolute_difference': float(np.max(abs(actual-expected)))}


def solve(arm, seed, budget, out, binary):
    directory = out / arm
    if arm == 'SFAO':
        row = run_seed(seed, budget, directory)
        return {'algorithm': arm, **row}
    output = subprocess.check_output([str(binary), str(DATA), str(seed), str(budget)], text=True)
    trace = [(int(i), float(v)) for i, v in (line.split() for line in output.splitlines())]
    evaluations, errors = map(np.array, zip(*trace))
    if (evaluations[0] != 1 or evaluations[-1] != budget or
            np.any(np.diff(evaluations) <= 0) or np.any(np.diff(errors) > 0) or
            not np.all(np.isfinite(errors)) or np.any(errors < 0)):
        raise RuntimeError(f'Invalid trace for {arm}, seed {seed}')
    hits = evaluations[errors < TARGET]
    error = float(errors[-1])
    row = dict(seed=seed, budget_fe=budget, raw_final_error=error,
               zeroed_final_error=0.0 if error < ZERO else error,
               success=bool(len(hits)), first_target_fe=int(hits[0]) if len(hits) else None)
    # Store exact FE indices of improvements, including the final budget.
    path = directory / f'run_{seed:02d}.npz'
    with path.with_suffix('.tmp').open('wb') as stream:
        np.savez_compressed(stream, evaluations=evaluations, best_so_far_error=errors)
    path.with_suffix('.tmp').replace(path)
    write_json(path.with_suffix('.json'), row)
    return {'algorithm': arm, **row}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--smoke', action='store_true')
    parser.add_argument('--workers', type=int, default=4)
    parser.add_argument('--cxx', default='g++')
    args = parser.parse_args()
    if args.workers < 1:
        parser.error('--workers must be positive')
    budget, seeds = (3000, [0]) if args.smoke else (BUDGET, list(range(30)))
    out = ROOT / ('results_smoke' if args.smoke else 'results')
    out.mkdir(exist_ok=True)
    arms = ('SFAO', 'RDE26-SOP')
    inputs = sorted([Path(__file__), ROOT/'run_f2.py', ROOT/'sfao.py',
                     ROOT/'sfao_final.py', ROOT/'cec2022.py']
                    + [p for p in SOURCE.iterdir() if p.is_file()]
                    + [p for p in DATA.parent.rglob('*') if p.suffix in ('.py', '.txt')])
    manifest = dict(function='CEC2022 F2', dimension=10, bounds=[-100, 100],
                    budget_fe=budget, seeds=seeds, algorithms=arms, target_strict_lt=TARGET,
                    zero_threshold=ZERO, rde_upstream_commit=PIN, python=sys.version,
                    platform=platform.platform(), numpy=np.__version__,
                    compiler=subprocess.check_output([args.cxx, '--version'], text=True),
                    sha256={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
                            for p in inputs})
    manifest = json.loads(json.dumps(manifest))
    manifest_path = out/'manifest.json'
    if manifest_path.exists() and json.loads(manifest_path.read_text()) != manifest:
        raise SystemExit(f'Inputs or environment changed. Rename {out.name} before rerunning.')
    binary = build(out, args.cxx)
    audit = check_evaluator(binary)
    write_json(out/'evaluator_check.json', audit)
    write_json(manifest_path, manifest)
    rows, pending = {}, []
    for arm in arms:
        (out/arm).mkdir(exist_ok=True)
        for seed in seeds:
            path = out/arm/f'run_{seed:02d}.json'
            if path.exists() and path.with_suffix('.npz').exists():
                row = json.loads(path.read_text())
                if row['seed'] != seed or row['budget_fe'] != budget:
                    raise RuntimeError(f'Invalid checkpoint: {path}')
                rows[arm, seed] = {'algorithm': arm, **row}
            else:
                pending.append((arm, seed))
    if pending:
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            futures = [pool.submit(solve, arm, seed, budget, out, binary) for arm, seed in pending]
            for future in as_completed(futures):
                row = future.result()
                rows[row['algorithm'], row['seed']] = row
                print(f'{len(rows)}/{len(arms)*len(seeds)} {row["algorithm"]} seed={row["seed"]} '
                      f'error={row["raw_final_error"]:.8g} first FE={row["first_target_fe"]}', flush=True)
    fields = ('algorithm', 'seed', 'budget_fe', 'raw_final_error', 'zeroed_final_error',
              'success', 'first_target_fe')
    summary = {}
    with (out/'run_summary.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        for arm in arms:
            group = [rows[arm, seed] for seed in seeds]
            writer.writerows(group)
            errors = np.array([r['raw_final_error'] for r in group])
            hits = [r['first_target_fe'] for r in group if r['success']]
            summary[arm] = dict(runs=len(group), successes=len(hits), mean_error=float(errors.mean()),
                                median_error=float(np.median(errors)),
                                sd_error=float(errors.std(ddof=1)) if len(group) > 1 else None,
                                median_fe_among_hits=float(np.median(hits)) if hits else None)
    write_json(out/'summary.json', summary)
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
