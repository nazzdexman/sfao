#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
# Keep the virtual environment on the Linux filesystem, including when the
# extracted project lives on a Windows-mounted drive.
project_key="$(printf '%s' "$PWD" | sha256sum | cut -c1-16)"
venv_dir="${XDG_CACHE_HOME:-$HOME/.cache}/sfao-f2-pc/$project_key"
if [[ ! -x "$venv_dir/bin/python" ]]; then
    python3 -m venv "$venv_dir"
fi
if ! "$venv_dir/bin/python" -c 'import numpy; assert numpy.__version__ == "2.3.5"' 2>/dev/null; then
    "$venv_dir/bin/python" -m pip install -r requirements.txt
fi
exec "$venv_dir/bin/python" run_comparison.py "$@"
