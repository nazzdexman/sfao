"""Independently verify saved endpoint, budget, hit index and cell counts."""
import csv
import json
from pathlib import Path
import sys
import numpy as np

def main(out):
    manifest = json.loads((out / 'manifest.json').read_text())
    summary = json.loads((out / 'summary.json').read_text())
    with (out / 'runs.csv').open(newline='') as stream:
        rows = list(csv.DictReader(stream))
    start_seed, end_seed = manifest['seed_range']
    arms = list(manifest['arms'])
    assert len(rows) == len(arms)*(end_seed-start_seed+1)
    actual = {}
    for row in rows:
        arm, seed = row['arm'], int(row['seed'])
        assert (arm, seed) not in actual
        with np.load(out / f'{arm}_{seed:02d}.npz', allow_pickle=False) as record:
            c, x = record['best_so_far_error'], record['best_x']
        assert len(c) == int(row['budget_fe']) == manifest['budget_fe']
        assert np.isfinite(c).all() and np.all(np.diff(c) <= 0) and np.all(c >= 0)
        assert x.shape == (manifest['dimension'],) and np.isfinite(x).all()
        lo, hi = manifest['bounds']
        assert np.all((x >= lo) & (x <= hi))
        hits = np.flatnonzero(c < manifest['primary_target'])
        assert row['first_hit_fe'] == (str(hits[0]+1) if len(hits) else '')
        assert (bool(row['first_m7_fe'])) == manifest['arms'][arm][0]
        assert float(row['raw_error']) == c[-1]
        error = 0.0 if c[-1] < manifest['zero_threshold'] else float(c[-1])
        assert float(row['recorded_error']) == error
        actual[arm, seed] = error
    for t, stats in summary['targets'].items():
        counts = {arm:sum(actual[arm, s] < float(t) for s in range(start_seed, end_seed+1)) for arm in arms}
        assert counts == stats['successes']
        effect = (counts['full']-counts['no_m7']-counts['no_m8']+counts['neither'])/(end_seed-start_seed+1)
        assert np.isclose(stats['contrasts']['M7xM8']['estimate'],effect)
    print(f'Verified {len(rows)} runs, all FE-indexed traces and all five target summaries.')

if __name__ == '__main__':
    main(Path(sys.argv[1]))
