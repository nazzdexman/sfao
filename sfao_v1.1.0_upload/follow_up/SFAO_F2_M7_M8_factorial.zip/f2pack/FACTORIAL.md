# CEC2022 F2 — M7 × M8 factorial

This follow-up uses CEC2022 F2, D = 10, bounds [-100, 100], 200,000 function evaluations per run and the same seed labels 0–29 in each of four configurations of locked SFAO. The four groups are full, M7 disabled, M8 disabled and both disabled. All 120 runs were executed here under one environment. The separate Apple M1 and original archive runs are outside this factorial.

Run from the source directory with Python 3.12 and NumPy 2.3.5:

```sh
python -m pip install -r requirements.txt
python run_factorial.py path/to/results --workers 8
```

The runner resumes complete seed files when the manifest matches. It verifies each trace as it is written. The results contain unzeroed best-so-far errors at every evaluation (zero-based array position 0 corresponds to FE 1), the final evaluated incumbent vector, first spinning FE, first attainment of error < 0.001, and raw and zeroed final errors. Results below 1e-8 are zeroed only for endpoint reporting. The manifest records the configuration, environment and input checksums.

The interaction is full minus no M7 minus no M8 plus neither. Positive values on target attainment indicate an above-additive success proportion, while a negative mean-error interaction indicates a larger combined reduction in error. The percentile confidence intervals use 20,000 bootstrap resamples of whole seed blocks, preserving all four results within each block. The focal target 0.001 follows the existing study; the four additional thresholds are sensitivity checks, with unadjusted intervals. Results apply to this objective, budget and implementation. The switches affect how the algorithm operates and may change its random number consumption. They do not isolate the effect of learned geometry at a fixed late-stage allocation.
