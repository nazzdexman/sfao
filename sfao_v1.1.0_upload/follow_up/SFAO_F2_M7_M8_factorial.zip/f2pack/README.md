# SFAO CEC2022 F2 — รันซ้ำ 30 seed

รันเฉพาะ SFAO ตัวเต็ม `SFAO:cocoon:aspin` บน CEC2022 F2, 10 มิติ, ขอบเขต [-100, 100], 200,000 FE ต่อรอบ, seed 0–29 และนับว่าเข้าเป้าเมื่อ error < 0.001

## รันบน Windows

แตก ZIP แล้วเปิด PowerShell ในโฟลเดอร์ที่มี `run_f2.py` แนะนำ Python 3.12 ขึ้นไปที่รองรับ NumPy รุ่นที่กำหนด

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe run_f2.py --smoke --workers 1
.\.venv\Scripts\python.exe run_f2.py --workers 4
```

บน Linux/macOS ใช้ `python3.12 -m venv .venv` แล้วแทนคำสั่ง Python ด้วย `./.venv/bin/python`

ถ้ารันค้าง ให้ใช้คำสั่งเดิมกับโฟลเดอร์ผลลัพธ์เดิมเพื่อรันต่อ โปรแกรมข้ามเฉพาะ seed ที่บันทึกทั้ง JSON และ NPZ สำเร็จแล้ว ถ้าเครื่องหรือสภาพแวดล้อมเปลี่ยน ให้ระบุโฟลเดอร์ใหม่ เช่น `--out f2_results_new` เพื่อไม่ให้ผลคนละสภาพแวดล้อมปนกัน โปรแกรมใช้หนึ่งเธรดต่อ worker สำหรับ BLAS

## ผลลัพธ์

- `f2_results/run_summary.csv` — ค่าก่อนและหลังใช้กฎ zeroing, สำเร็จหรือไม่, FE แรกที่เข้าเป้า, FE แรกที่เริ่ม M7 และค่า final error จาก archive แยกคอลัมน์
- `f2_results/run_*.npz` — `best_so_far_error` หนึ่งค่าต่อ FE โดย index 0 คือ FE 1 พร้อม `best_x`
- `f2_results/summary.json` — สรุปผลของชุดรันใหม่และจำนวนรอบสำเร็จใน archive
- `f2_results/manifest.json` — การตั้งค่า สภาพแวดล้อม และ SHA-256 ของไฟล์ที่ใช้รัน

เก็บค่า best-so-far ก่อนใช้กฎ zeroing ของบทความ ค่าสถิติปลายรอบใช้กฎ error < 1e-8 ให้เป็นศูนย์ตามงานเดิม ผลจาก archive เป็นค่าที่ผ่านกฎนี้แล้ว ชุดรันเต็มเริ่ม seed 0–29 ใหม่เพื่อให้ทั้งชุดอยู่ในสภาพแวดล้อมเดียวกัน ผลต่างระหว่างเครื่องหรือชุดไลบรารีเป็นไปได้ เมื่อรันเสร็จส่งโฟลเดอร์ `f2_results` เป็น ZIP เพื่อให้ตรวจทั้งสรุปและ trace ได้

ซอร์สหลักมาจาก SFAO v1.0.0 (https://doi.org/10.5281/zenodo.24051942) ใช้สำเนารุ่นตรวจผลที่บันทึก FE แรกของ M7 และค่า best-so-far โดยการตั้งค่ารันใช้ clipping ตามค่าเริ่มต้น
