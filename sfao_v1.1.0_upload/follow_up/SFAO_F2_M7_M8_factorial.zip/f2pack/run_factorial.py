from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
import argparse
import csv
import hashlib
import json
import platform
import sys

from run_f2 import BUDGET, TARGET, ZERO, CEC2022, np, sfao_final, write_json

ARMS = {'full': (True, True), 'no_m7': (False, True),
        'no_m8': (True, False), 'neither': (False, False)}
TARGETS = (1e-6, 1e-4, TARGET, 1e-2, 1e-1)

def run(arm, seed, out):
    m7, m8 = ARMS[arm]
    s = sfao_final(use_spin=m7, use_memory=m8)
    best, e, c = s.optimize(CEC2022(2, 10), 10, -100, 100, BUDGET, seed=seed)
    assert len(c) == s.fe == BUDGET and np.isfinite(c).all()
    assert c[-1] == e and np.all(c >= 0) and np.all(np.diff(c) <= 0)
    assert (s.revision_m7_first_fe is not None) == m7
    hits = np.flatnonzero(c < TARGET)
    row = dict(arm=arm, seed=seed, budget_fe=s.fe, raw_error=float(e),
               recorded_error=0.0 if e < ZERO else float(e),
               first_hit_fe=int(hits[0])+1 if len(hits) else None,
               first_m7_fe=s.revision_m7_first_fe)
    p = out / f'{arm}_{seed:02d}'
    with p.with_suffix('.tmp').open('wb') as f:
        np.savez_compressed(f, best_so_far_error=c, best_x=best)
    p.with_suffix('.tmp').replace(p.with_suffix('.npz'))
    write_json(p.with_suffix('.json'), row)
    return row

def analyze(results, out):
    errors = np.array([[results[a, s]['recorded_error'] for s in range(30)] for a in ARMS])
    index = np.random.default_rng(821).integers(0, 30, (20_000, 30))
    coefficients = np.array([[.5,-.5,.5,-.5],[.5,.5,-.5,-.5],[1,-1,-1,1]])
    def contrasts(values):
        sample = coefficients @ values[:, index].mean(2)
        point = coefficients @ values.mean(1)
        return {k: dict(zip(('estimate','lower_95','upper_95'), map(float, v)))
                for k,v in zip(('M7','M8','M7xM8'), np.column_stack([point,np.quantile(sample,[.025,.975],axis=1).T]))}
    targets = {str(t): {'successes':dict(zip(ARMS,(errors<t).sum(1).tolist())),
                       'contrasts':contrasts((errors<t).astype(float))} for t in TARGETS}
    stats = dict(arms={a:dict(mean=float(np.mean(row)),median=float(np.median(row)),
                             sd=float(np.std(row,ddof=1))) for a,row in zip(ARMS,errors)},
                 targets=targets, mean_error_contrasts=contrasts(errors))
    write_json(out/'summary.json',stats)
    with (out/'runs.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f, fieldnames=list(next(iter(results.values()))))
        writer.writeheader()
        writer.writerows(results[a,s] for a in ARMS for s in range(30))
    print(json.dumps(stats,indent=2),flush=True)

def main():
    p = argparse.ArgumentParser()
    p.add_argument('out', type=Path)
    p.add_argument('--workers', type=int, default=8)
    args = p.parse_args()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    root = Path(__file__).resolve().parent
    inputs = [root / p for p in ('run_factorial.py','run_f2.py','sfao.py','sfao_final.py','cec2022.py')]
    inputs += sorted(p for p in (root/'cec2022_data').rglob('*') if p.suffix in ('.py','.txt'))
    manifest=dict(python=sys.version,numpy=np.__version__,numpy_build=np.show_config(mode='dicts'),
                  platform=platform.platform(),machine=platform.machine(),blas_threads=1,
                  sha256={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs},
                  suite='CEC2022 F2',dimension=10,bounds=[-100,100],budget_fe=BUDGET,
                  seed_range=[0,29],targets=TARGETS,primary_target=TARGET,zero_threshold=ZERO,arms=ARMS)
    config=out/'manifest.json'
    if config.exists() and json.dumps(json.loads(config.read_text()),sort_keys=True)!=json.dumps(manifest,sort_keys=True):
        raise SystemExit('Use a new output directory for this environment or configuration.')
    write_json(config,manifest)
    jobs=[(a,s) for s in range(30) for a in ARMS]
    results={}
    for arm,seed in jobs:
        path=out/f'{arm}_{seed:02d}.json'
        if path.exists() and path.with_suffix('.npz').exists():
            results[arm,seed]=json.loads(path.read_text())
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures=[pool.submit(run,arm,seed,out) for arm,seed in jobs if (arm,seed) not in results]
        for f in as_completed(futures):
            row=f.result()
            key=row['arm'],row['seed']
            results[key]=row
            print(f'{len(results)}/120 {key} {row["raw_error"]:.12g}',flush=True)
    analyze(results,out)

if __name__=='__main__':
    main()
