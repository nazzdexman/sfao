"""Reproduce locked SFAO on CEC2022 F2, with one checkpoint file per seed."""
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import csv
import hashlib
import json
import os
from pathlib import Path
import platform
import sys
import time

for key in ('OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'OMP_NUM_THREADS', 'BLIS_NUM_THREADS'):
    os.environ[key] = '1'

import numpy as np
from cec2022 import CEC2022
from sfao_final import sfao_final

ROOT = Path(__file__).resolve().parent
TARGET = 1e-3
ZERO = 1e-8
BUDGET = 200_000

def write_json(path, data):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(data, indent=2), encoding='utf-8')
    temp.replace(path)

def run_seed(seed, budget, out):
    start = time.perf_counter()
    optimizer = sfao_final()
    x, error, curve = optimizer.optimize(CEC2022(2, 10), 10, -100, 100, budget, seed=seed)
    if optimizer.fe != budget or len(curve) != budget or error != curve[-1]:
        raise RuntimeError(f'Invalid evaluation count or endpoint for seed {seed}')
    if not np.all(np.isfinite(curve)) or np.any(np.diff(curve) > 0):
        raise RuntimeError(f'Invalid best-so-far trace for seed {seed}')
    first = np.flatnonzero(curve < TARGET)
    row = dict(seed=seed, budget_fe=budget, raw_final_error=float(error),
               zeroed_final_error=0.0 if error < ZERO else float(error),
               success=bool(len(first)), first_target_fe=int(first[0])+1 if len(first) else None,
               first_m7_fe=optimizer.revision_m7_first_fe, seconds=time.perf_counter()-start)
    trace = out / f'run_{seed:02d}.npz'
    with trace.with_suffix('.tmp').open('wb') as f:
        np.savez_compressed(f, best_so_far_error=curve, best_x=x)
    trace.with_suffix('.tmp').replace(trace)
    write_json(out / f'run_{seed:02d}.json', row)
    return row

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workers', type=int, default=min(4, os.cpu_count() or 1))
    parser.add_argument('--out', type=Path, default=Path('f2_results'))
    parser.add_argument('--smoke', action='store_true', help='one 3,000-FE run in a separate output directory')
    args = parser.parse_args()
    if args.workers < 1:
        parser.error('--workers must be positive')
    budget, seeds = (3000, [0]) if args.smoke else (BUDGET, list(range(30)))
    out = args.out.resolve()
    if args.smoke:
        out = out.with_name(out.name + '_smoke')
    out.mkdir(parents=True, exist_ok=True)
    inputs = [ROOT / n for n in ('run_f2.py', 'sfao.py', 'sfao_final.py', 'cec2022.py', 'archived_endpoints.csv')]
    inputs.extend(p for p in (ROOT / 'cec2022_data').rglob('*') if p.suffix in ('.py', '.txt'))
    manifest = dict(function='CEC2022 F2', dimension=10, bounds=[-100, 100], budget_fe=budget,
                    target_strict_lt=TARGET, zero_threshold=ZERO, seeds=seeds, python=sys.version,
                    numpy=np.__version__, numpy_build=np.show_config(mode='dicts'),
                    platform=platform.platform(), machine=platform.machine(), blas_threads=1,
                    configuration='SFAO:cocoon:aspin',
                    sha256={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(inputs)})
    path = out / 'manifest.json'
    if path.exists() and json.loads(path.read_text(encoding='utf-8')) != manifest:
        raise SystemExit('Environment or inputs changed. Choose a new --out directory.')
    write_json(path, manifest)
    rows = {}
    for seed in seeds:
        p = out / f'run_{seed:02d}.json'
        if p.exists() and p.with_suffix('.npz').exists():
            row = json.loads(p.read_text(encoding='utf-8'))
            if row['seed'] != seed or row['budget_fe'] != budget:
                raise SystemExit(f'Unexpected checkpoint metadata: {p}')
            rows[seed] = row
    pending = [s for s in seeds if s not in rows]
    if pending:
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            futures = [pool.submit(run_seed, seed, budget, out) for seed in pending]
            for future in as_completed(futures):
                row = future.result()
                rows[row['seed']] = row
                print(f'{len(rows)}/{len(seeds)} | seed={row["seed"]:02d} | error={row["raw_final_error"]:.12g} | first target FE={row["first_target_fe"]}', flush=True)
    order = [rows[s] for s in seeds]
    with (ROOT / 'archived_endpoints.csv').open(newline='') as f:
        archived = {int(r['seed']): float(r['archived_final_error']) for r in csv.DictReader(f)}
    if not args.smoke:
        for row in order:
            row['archived_final_error'] = archived[row['seed']]
            row['archived_success'] = archived[row['seed']] < TARGET
    with (out / 'run_summary.csv').open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=list(order[0]))
        writer.writeheader()
        writer.writerows(order)
    values = np.array([r['zeroed_final_error'] for r in order])
    hits = [r['first_target_fe'] for r in order if r['success']]
    summary = dict(runs=len(order), successes=len(hits), mean_final_error=float(values.mean()),
                   median_final_error=float(np.median(values)),
                   sample_sd_final_error=float(values.std(ddof=1)) if len(values) > 1 else None,
                   median_target_fe_among_successes=float(np.median(hits)) if hits else None)
    if not args.smoke:
        summary['archived_successes'] = sum(r['archived_success'] for r in order)
    write_json(out / 'summary.json', summary)
    print(json.dumps(summary, indent=2), flush=True)
    print(out)

if __name__ == '__main__':
    main()
